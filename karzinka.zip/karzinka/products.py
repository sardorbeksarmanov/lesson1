from classes import Product

def product_operations():
    while True:
        operation = input("""
            Product Operations
            1. Select
            2. Insert
            3. Update
            4. Delete
            5. Back
            >>> """)

        if operation == "1":
            # Select operation
            products = Product.select()
            print("Products:")
            for product in products:
                print(product)

        elif operation == "2":
            name = input("Enter product name: ")
            description = input("Enter product description: ")
            price = float(input("Enter product price: "))
            count = int(input("Enter product count: "))
            serial_number = input("Enter product serial number: ")
            start_date = input("Enter product start date (YYYY-MM-DD): ")
            end_date = input("Enter product end date (YYYY-MM-DD): ")
            store_id = int(input("Enter store ID: "))
            category_id = int(input("Enter category ID: "))
            Product.insert(name, description, price, count, serial_number, start_date, end_date, store_id, category_id)

        elif operation == "3":
            product_id = input("Enter product ID: ")
            new_name = input("Enter new product name: ")
            new_description = input("Enter new product description: ")
            new_price = float(input("Enter new product price: "))
            new_count = int(input("Enter new product count: "))
            new_serial_number = input("Enter new product serial number: ")
            new_start_date = input("Enter new product start date (YYYY-MM-DD): ")
            new_end_date = input("Enter new product end date (YYYY-MM-DD): ")
            new_store_id = int(input("Enter new store ID: "))
            new_category_id = int(input("Enter new category ID: "))
            Product.update(product_id, new_name, new_description, new_price, new_count, new_serial_number, new_start_date, new_end_date, new_store_id, new_category_id)

        elif operation == "4":
            product_id = input("Enter product ID to delete: ")
            Product.delete(product_id)

        elif operation == "5":
            break

        else:
            print("Invalid operation!")

if __name__ == "__main__":
    product_operations()
