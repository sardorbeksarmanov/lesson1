from classes import Inventory

def inventory_operations():
    while True:
        operation = input("""
            Inventory Operations
            1. Select
            2. Insert
            3. Update
            4. Delete
            5. Back
            >>> """)

        if operation == "1":
            # Select operation
            inventories = Inventory.select()
            print("Inventories:")
            for inventory in inventories:
                print(inventory)

        elif operation == "2":
            product_id = input("Enter product ID: ")
            quantity = input("Enter quantity: ")
            inventory = Inventory()
            inventory.insert(product_id, quantity)


        elif operation == "3":
            product_id = input("Enter product ID to update: ")
            new_quantity = input("Enter new quantity: ")
            Inventory.update(product_id, new_quantity)
            print("Inventory updated successfully!")

        elif operation == "4":
            product_id = input("Enter product ID to delete: ")
            Inventory.delete(product_id)
            print("Inventory deleted successfully!")
        else:
            print("Invalid operation!")

if __name__ == "__main__":
    inventory_operations()
