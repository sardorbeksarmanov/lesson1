from manage import Database

class Userlar:
    @staticmethod
    def select():
        query = "SELECT * FROM users ORDER BY id"  # "id" ustunini ishlatamiz
        return Database.connect(query, "select")

    @staticmethod
    def insert(username, password):
        query = f"INSERT INTO users (username, password) VALUES ('{username}', '{password}')"
        return Database.connect(query, "insert")

    @staticmethod
    def update(user_id, new_username, new_password):
        query = f"UPDATE users SET username = '{new_username}', password = '{new_password}' WHERE id = {user_id}"
        return Database.connect(query, "update")

    @staticmethod
    def delete(user_id):
        query = f"DELETE FROM users WHERE id = {user_id}"
        return Database.connect(query, "delete")




class Product:
    table_name = "products"

    def __init__(self, name, price, barcode):
        self.name = name
        self.price = price
        self.barcode = barcode

    @staticmethod
    def select():
        query = f"SELECT * FROM {Product.table_name} ORDER BY product_id"
        return Database.connect(query, "select")

    def insert(self, name, description, price, count, serial_number, start_date, end_date, store_id, category_id):
        query = f"""
            INSERT INTO products (name, description, price, count, serial_number, start_date, end_date, store_id, category_id) 
            VALUES ('{name}', '{description}', {price}, {count}, '{serial_number}', '{start_date}', '{end_date}', {store_id}, {category_id});
        """
        return Database.connect(query, "insert")

    @staticmethod
    def update(column, new_data, old_data):
        if column == "product_id":
            query = f"UPDATE {Product.table_name} SET {column} = {new_data} WHERE {column} = {old_data}"
        else:
            query = f"UPDATE {Product.table_name} SET {column} = '{new_data}' WHERE {column} = '{old_data}'"
        return Database.connect(query, "update")

    @staticmethod
    def delete(column, data):
        if column == "product_id":
            query = f"DELETE FROM {Product.table_name} WHERE {column} = {data}"
        else:
            query = f"DELETE FROM {Product.table_name} WHERE {column} = '{data}'"
        return Database.connect(query, "delete")

class Orders:
    table_name = "orders"

    @staticmethod
    def select():
        query = f"SELECT * FROM {Orders.table_name} ORDER BY order_id"
        return Database.connect(query, "select")

    @staticmethod
    def insert(user_id, shipper_id, total_price, order_date):
        query = f"""
                INSERT INTO {Orders.table_name} (user_id, shipper_id, total_price, order_date) 
                VALUES ({user_id}, {shipper_id}, {total_price}, '{order_date}')
            """
        return Database.connect(query, "insert")

    @staticmethod
    def update(order_id, user_id, shipper_id, total_price, order_date):
        query = f"""
                UPDATE {Orders.table_name}
                SET user_id = {user_id}, shipper_id = {shipper_id}, total_price = {total_price}, order_date = '{order_date}'
                WHERE order_id = {order_id}
            """
        return Database.connect(query, "update")

    @staticmethod
    def delete(order_id):
        query = f"""
                DELETE FROM {Orders.table_name}
                WHERE order_id = {order_id}
            """
        return Database.connect(query, "delete")

class Payments:
    table_name = "payments"

    def __init__(self, user_id, amount, payment_date):
        self.user_id = user_id
        self.amount = amount
        self.payment_date = payment_date

    @staticmethod
    def select():
        query = f"SELECT * FROM {Payments.table_name} ORDER BY payment_id"
        return Database.connect(query, "select")

    def insert(self):
        query = f"""
            INSERT INTO {Payments.table_name} (user_id, amount, payment_date) 
            VALUES ({self.user_id}, {self.amount}, '{self.payment_date}')
        """
        return Database.connect(query, "insert")

    @staticmethod
    def update(column, new_data, old_data):
        if column == "payment_id":
            query = f"UPDATE {Payments.table_name} SET {column} = {new_data} WHERE {column} = {old_data}"
        else:
            query = f"UPDATE {Payments.table_name} SET {column} = '{new_data}' WHERE {column} = '{old_data}'"
        return Database.connect(query, "update")

    @staticmethod
    def delete(column, data):
        if column == "payment_id":
            query = f"DELETE FROM {Payments.table_name} WHERE {column} = {data}"
        else:
            query = f"DELETE FROM {Payments.table_name} WHERE {column} = '{data}'"
        return Database.connect(query, "delete")

class Categories:
    table_name = "categories"

    def __init__(self, name, description):
        self.name = name
        self.description = description

    @staticmethod
    def select():
        query = f"SELECT * FROM {Categories.table_name} ORDER BY category_id"
        return Database.connect(query, "select")

    def insert(self):
        query = f"""
            INSERT INTO {Categories.table_name} (name, description) 
            VALUES ('{self.name}', '{self.description}')
        """
        return Database.connect(query, "insert")

    @staticmethod
    def update(column, new_data, old_data):
        if column == "category_id":
            query = f"UPDATE {Categories.table_name} SET {column} = {new_data} WHERE {column} = {old_data}"
        else:
            query = f"UPDATE {Categories.table_name} SET {column} = '{new_data}' WHERE {column} = '{old_data}'"
        return Database.connect(query, "update")

    @staticmethod
    def delete(column, data):
        if column == "category_id":
            query = f"DELETE FROM {Categories.table_name} WHERE {column} = {data}"
        else:
            query = f"DELETE FROM {Categories.table_name} WHERE {column} = '{data}'"
        return Database.connect(query, "delete")



class Suppliers:
    class Suppliers:
        def __init__(self, name, address, contact, email):
            self.name = name
            self.address = address
            self.contact = contact
            self.email = email

    @staticmethod
    def select():
        query = "SELECT * FROM suppliers ORDER BY id"
        Database.connect(query, "select")

    @staticmethod
    def insert(name, address, phone, email):
        query = f"INSERT INTO suppliers (name, address, phone, email) VALUES ('{name}', '{address}', '{phone}', '{email}')"
        Database.connect(query, "insert")

    @staticmethod
    def update(supplier_id, name, address, phone, email):
        query = f"UPDATE suppliers SET name = '{name}', address = '{address}', phone = '{phone}', email = '{email}' WHERE id = {supplier_id}"
        Database.connect(query, "update")

    @staticmethod
    def delete(supplier_id):
        query = f"DELETE FROM suppliers WHERE id = {supplier_id}"
        Database.connect(query, "delete")


class Shippers:
    table_name = "shippers"

    def __init__(self, name, address, phone, email):
        self.name = name
        self.address = address
        self.phone = phone
        self.email = email

    @staticmethod
    def select():
        query = f"SELECT * FROM {Shippers.table_name} ORDER BY shipper_id"
        return Database.connect(query, "select")

    def insert(self):
        query = f"""
            INSERT INTO {Shippers.table_name} (name, address, phone, email) 
            VALUES ('{self.name}', '{self.address}', '{self.phone}', '{self.email}')
        """
        return Database.connect(query, "insert")

    @staticmethod
    def update(column, new_data, old_data):
        if column == "shipper_id":
            query = f"UPDATE {Shippers.table_name} SET {column} = {new_data} WHERE {column} = {old_data}"
        else:
            query = f"UPDATE {Shippers.table_name} SET {column} = '{new_data}' WHERE {column} = '{old_data}'"
        return Database.connect(query, "update")

    @staticmethod
    def delete(column, data):
        if column == "shipper_id":
            query = f"DELETE FROM {Shippers.table_name} WHERE {column} = {data}"
        else:
            query = f"DELETE FROM {Shippers.table_name} WHERE {column} = '{data}'"
        return Database.connect(query, "delete")


class Reports:
    table_name = "reports"

    def __init__(self, order_id, user_id, shipper_id, product_id, quantity, price, total_price, report_date):
        self.order_id = order_id
        self.user_id = user_id
        self.shipper_id = shipper_id
        self.product_id = product_id
        self.quantity = quantity
        self.price = price
        self.total_price = total_price
        self.report_date = report_date

    @staticmethod
    def select():
        query = f"SELECT * FROM {Reports.table_name} ORDER BY report_id"
        return Database.connect(query, "select")

    def insert(self):
        query = f"""
            INSERT INTO {Reports.table_name} (order_id, user_id, shipper_id, product_id, quantity, price, total_price, report_date) 
            VALUES ({self.order_id}, {self.user_id}, {self.shipper_id}, {self.product_id}, {self.quantity}, {self.price}, {self.total_price}, '{self.report_date}')
        """
        return Database.connect(query, "insert")

    @staticmethod
    def update(column, new_data, old_data):
        if column == "report_id":
            query = f"UPDATE {Reports.table_name} SET {column} = {new_data} WHERE {column} = {old_data}"
        else:
            query = f"UPDATE {Reports.table_name} SET {column} = '{new_data}' WHERE {column} = '{old_data}'"
        return Database.connect(query, "update")

    @staticmethod
    def delete(column, data):
        if column == "report_id":
            query = f"DELETE FROM {Reports.table_name} WHERE {column} = {data}"
        else:
            query = f"DELETE FROM {Reports.table_name} WHERE {column} = '{data}'"
        return Database.connect(query, "delete")


class Discounts:
    table_name = "discounts"

    def __init__(self, product_id, discount_amount, expiry_date, description):
        self.product_id = product_id
        self.discount_amount = discount_amount
        self.expiry_date = expiry_date
        self.description = description

    @staticmethod
    def select():
        query = f"SELECT * FROM {Discounts.table_name} ORDER BY discount_id"
        return Database.connect(query, "select")

    def insert(self):
        query = f"""
            INSERT INTO {Discounts.table_name} (product_id, discount_amount, expiry_date, description) 
            VALUES ({self.product_id}, {self.discount_amount}, '{self.expiry_date}', '{self.description}')
        """
        return Database.connect(query, "insert")

    @staticmethod
    def update(column, new_data, old_data):
        if column == "discount_id":
            query = f"UPDATE {Discounts.table_name} SET {column} = {new_data} WHERE {column} = {old_data}"
        else:
            query = f"UPDATE {Discounts.table_name} SET {column} = '{new_data}' WHERE {column} = '{old_data}'"
        return Database.connect(query, "update")

    @staticmethod
    def delete(column, data):
        if column == "discount_id":
            query = f"DELETE FROM {Discounts.table_name} WHERE {column} = {data}"
        else:
            query = f"DELETE FROM {Discounts.table_name} WHERE {column} = '{data}'"
        return Database.connect(query, "delete")


class Inventory:
    table_name = "inventory"

    def __init__(self, product_id, stock_quantity, last_updated):
        self.product_id = product_id
        self.stock_quantity = stock_quantity
        self.last_updated = last_updated

    @staticmethod
    def select():
        query = f"SELECT * FROM {Inventory.table_name} ORDER BY inventory_id"
        return Database.connect(query, "select")

    def insert(self):
        query = f"""
            INSERT INTO {Inventory.table_name} (product_id, stock_quantity, last_updated) 
            VALUES ({self.product_id}, {self.stock_quantity}, '{self.last_updated}')
        """
        return Database.connect(query, "insert")

    @staticmethod
    def update(column, new_data, old_data):
        if column == "inventory_id":
            query = f"UPDATE {Inventory.table_name} SET {column} = {new_data} WHERE {column} = {old_data}"
        else:
            query = f"UPDATE {Inventory.table_name} SET {column} = '{new_data}' WHERE {column} = '{old_data}'"
        return Database.connect(query, "update")

    @staticmethod
    def delete(column, data):
        if column == "inventory_id":
            query = f"DELETE FROM {Inventory.table_name} WHERE {column} = {data}"
        else:
            query = f"DELETE FROM {Inventory.table_name} WHERE {column} = '{data}'"
        return Database.connect(query, "delete")
