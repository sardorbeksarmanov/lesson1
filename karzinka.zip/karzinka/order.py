from classes import Orders

def order_operations():
    while True:
        operation = input("""
            Order Operations
            1. Select
            2. Insert
            3. Update
            4. Delete
            5. Back
            >>> """)

        if operation == "1":
            orders = Orders.select()
            print("Orders:")
            for order in orders:
                print(order)

        elif operation == "2":
            customer_id = input("Enter customer ID: ")
            product_id = input("Enter product ID: ")
            quantity = int(input("Enter quantity: "))
            Orders.insert(customer_id, product_id, quantity)

        elif operation == "3":
            order_id = input("Enter order ID: ")
            new_quantity = int(input("Enter new quantity: "))
            Orders.update(order_id, new_quantity)

        elif operation == "4":
            order_id = input("Enter order ID to delete: ")
            Orders.delete(order_id)

        elif operation == "5":
            # Back to previous menu
            break

        else:
            print("Invalid operation!")

if __name__ == "__main__":
    order_operations()
