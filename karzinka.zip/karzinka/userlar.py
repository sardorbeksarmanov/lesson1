from classes import Userlar
from project import website
def user_operations():
    while True:
        operation = input("""
            User Operations
            1. Select
            2. Insert
            3. Update
            4. Delete
            5. Back
            >>> """)

        if operation == "1":
            # Select operation
            users = Userlar.select()
            print("Users:")
            for user in users:
                print(user)

        elif operation == "2":
            username = input("Enter username: ")
            password = input("Enter password: ")
            Userlar.insert(username, password)



        elif operation == "3":
            user_id = input("Enter user ID: ")
            new_username = input("Enter new username: ")
            new_password = input("Enter new password: ")
            Userlar.update(user_id, new_username, new_password)



        elif operation == "4":
            user_id = input("Enter user ID to delete: ")
            Userlar.delete(user_id)


        elif operation == "5":
            break

        else:
            print("Invalid operation!")

# if __name__ == "__main__":
#     user_operations()