import invemtory
import order
from classes import Userlar, Product, Orders, Payments, Categories, Suppliers, Shippers, Reports, Discounts, Inventory
from manage import Check
import products
from manage import Database
import userlar
import payments
import categories
import suppliers
import shippers
import discounts
import invemtory

def website(username, password):
    web = input("""
        Website
            1. userlar
            2. products
            3. orders
            4. payments
            5. categories
            6. suppliers
            7. shippers
            8. reports
            9. discounts
            10. inventory
            11. exit
                >>> """)

    if web == "1":
        return userlar.user_operations()

    elif web == "2":
        return products.product_operations()

    elif web == "3":
        return order.order_operations()

    elif web == "4":
        return payments.payment_operations()

    elif web == "5":
        return categories.category_operations()

    elif web == "6":
        return suppliers.supplier_operations()

    elif web == "7":
        return shippers.shipper_operations()

    elif web == "8":
        return Reports

    elif web == "9":
        return discounts.discounts_operations()

    elif web == "10":
        return invemtory.inventory_operations()

    elif web == "11":
        return None

    else:
        print("Error")
        return website(username, password)

if __name__ == '__main__':
    website("userlar", "password")