from classes import Suppliers


def select_suppliers():
    suppliers = Suppliers.select()
    if suppliers:
        print("Suppliers:")
        for supplier in suppliers:
            print(supplier)
    else:
        print("No suppliers found.")


def insert_supplier():
    name = input("Enter supplier name: ")
    address = input("Enter supplier address: ")
    contact = input("Enter supplier contact info: ")
    email = input("Enter supplier email: ")
    Suppliers.insert(name, address, contact, email)
    print("Supplier inserted successfully.")


def update_supplier():
    supplier_id = input("Enter supplier ID to update: ")
    name = input("Enter new supplier name: ")
    address = input("Enter new supplier address: ")
    contact = input("Enter new supplier contact info: ")
    email = input("Enter new supplier email: ")
    Suppliers.update(supplier_id, name, address, contact, email)
    print("Supplier updated successfully.")


def delete_supplier():
    supplier_id = input("Enter supplier ID to delete: ")
    Suppliers.delete(supplier_id)
    print("Supplier deleted successfully.")


def supplier_operations():
    while True:
        operation = input("""
            Supplier Operations
            1. Select
            2. Insert
            3. Update
            4. Delete
            5. Back
            >>> """)

        if operation == "1":
            select_suppliers()
        elif operation == "2":
            insert_supplier()
        elif operation == "3":
            update_supplier()
        elif operation == "4":
            delete_supplier()
        elif operation == "5":
            break
        else:
            print("Invalid operation!")


if __name__ == "__main__":
    supplier_operations()
