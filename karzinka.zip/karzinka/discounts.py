from classes import Discounts

def discounts_operations():
    while True:
        operation = input("""
            Discounts Operations
            1. Select
            2. Insert
            3. Update
            4. Delete
            5. Back
            >>> """)

        if operation == "1":
            # Select operation
            discounts = Discounts.select()
            print("Discounts:")
            for discount in discounts:
                print(discount)

        elif operation == "2":
            # Insert operation
            discount_rate = float(input("Enter discount rate: "))
            description = input("Enter description: ")
            Discounts.insert(discount_rate, description)

        elif operation == "3":
            # Update operation
            discount_id = input("Enter discount ID: ")
            new_discount_rate = float(input("Enter new discount rate: "))
            new_description = input("Enter new description: ")
            Discounts.update(discount_id, new_discount_rate, new_description)

        elif operation == "4":
            # Delete operation
            discount_id = input("Enter discount ID to delete: ")
            Discounts.delete(discount_id)

        elif operation == "5":
            # Back to previous menu
            break

        else:
            print("Invalid operation!")

if __name__ == "__main__":
    discounts_operations()
