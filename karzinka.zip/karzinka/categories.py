from classes import Categories

def category_operations():
    while True:
        operation = input("""
            Category Operations
            1. Select
            2. Insert
            3. Update
            4. Delete
            5. Back
            >>> """)

        if operation == "1":
            # Select operation
            categories = Categories.select()
            print("Categories:")
            for category in categories:
                print(category)

        elif operation == "2":
            name = input("Enter category name: ")
            description = input("Enter category description: ")
            Categories.insert(name, description)
            print("Category inserted successfully!")

        elif operation == "3":
            category_id = input("Enter category ID to update: ")
            new_name = input("Enter new category name: ")
            new_description = input("Enter new category description: ")
            Categories.update(category_id, new_name, new_description)
            print("Category updated successfully!")

        elif operation == "4":
            category_id = input("Enter category ID to delete: ")
            Categories.delete(category_id)
            print("Category deleted successfully!")

        elif operation == "5":
            break

        else:
            print("Invalid operation!")

if __name__ == "__main__":
    category_operations()
