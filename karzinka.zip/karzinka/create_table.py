from manage import Database

def create_table():
    userlar = f"""
        CREATE TABLE userlar(
            id SERIAL PRIMARY KEY,
            name VARCHAR(50),
            elektron_pochta VARCHAR(150),
            parol VARCHAR(150),
            create_date TIMESTAMP DEFAULT now());"""

    Products = f"""
            CREATE TABLE product(
                id SERIAL PRIMARY KEY,
                name VARCHAR(50),
                price INTEGER,
                shtrix_kodi INTEGER,
                create_date TIMESTAMP DEFAULT now());"""

    Orders = f"""
            CREATE TABLE orders(
                id SERIAL PRIMARY KEY,
                user_id SERIAL PRIMARY KEY,
                product_id INT REFERENCES product(id),
                create_date TIMESTAMP DEFAULT now(),
                amount INTEGER,
                status VARCHAR(50));"""

    Payments = f"""
               CREATE TABLE payments(
                   payment_id SERIAL PRIMARY KEY,
                   order_id INT REFERENCES orders(id),
                   payment_type VARCHAR(50),
                   amount NUMERIC(10, 2),
                   payment_date DATE,
                   additional_info TEXT);"""


    categories = f"""
            CREATE TABLE categories(
                id SERIAL PRIMARY KEY,
                name VARCHAR(50),
                description VARCHAR(150),
                create_date TIMESTAMP DEFAULT now());"""

    suppliers_table = """
    CREATE TABLE suppliers (
        supplier_id SERIAL PRIMARY KEY,
        name VARCHAR(100),
        address TEXT,
        phone VARCHAR(20),
        email VARCHAR(100)
    );
    """

    shippers_table = """
    CREATE TABLE shippers (
        shipper_id SERIAL PRIMARY KEY,
        name VARCHAR(100),
        address TEXT,
        phone VARCHAR(20),
        email VARCHAR(100)
    );
    """

    reports_table = """
    CREATE TABLE reports (
        report_id SERIAL PRIMARY KEY,
        order_id INT REFERENCES orders(order_id),
        user_id INT REFERENCES users(user_id),
        shipper_id INT REFERENCES shippers(shipper_id),
        product_id INT REFERENCES products(product_id),
        quantity INT,
        price NUMERIC(10, 2),
        total_price NUMERIC(10, 2),
        report_date DATE
    );
    """

    discounts_table = """
    CREATE TABLE discounts (
        discount_id SERIAL PRIMARY KEY,
        product_id INT REFERENCES products(product_id),
        discount_amount NUMERIC(10, 2),
        expiry_date DATE,
        description TEXT
    );
    """

    inventory_table = """
    CREATE TABLE inventory (
        inventory_id SERIAL PRIMARY KEY,
        product_id INT REFERENCES products(product_id),
        stock_quantity INT,
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """

    data = {
            "users": userlar,
            "products": Products,
            "orders": Orders,
            "payments": payments,
            "categories": categories,
            "suppliers": suppliers_table,
            "shippers": shippers_table,
            "reports": reports_table,
            "discounts": discounts_table,
            "inventory": inventory_table
            }
    for i in data:
        print(f"{i} {Database.connect(data[i], "create")}")

if __name__ == "__main__":
    create_table()


