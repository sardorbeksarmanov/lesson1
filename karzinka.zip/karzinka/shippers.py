from classes import Shippers

def shipper_operations():
    while True:
        operation = input("""
            Shipper Operations
            1. Select
            2. Insert
            3. Update
            4. Delete
            5. Back
            >>> """)

        if operation == "1":
            # Select operation
            shippers = Shippers.select()
            print("Shippers:")
            for shipper in shippers:
                print(shipper)

        elif operation == "2":
            name = input("Enter shipper name: ")
            contact = input("Enter shipper contact info: ")
            Shippers.insert(name, contact)

        elif operation == "3":
            shipper_id = input("Enter shipper ID: ")
            new_name = input("Enter new shipper name: ")
            new_contact = input("Enter new shipper contact info: ")
            Shippers.update(shipper_id, new_name, new_contact)

        elif operation == "4":
            shipper_id = input("Enter shipper ID to delete: ")
            Shippers.delete(shipper_id)

        elif operation == "5":
            break

        else:
            print("Invalid operation!")

if __name__ == "__main__":
    shipper_operations()
