from classes import Payments


def user_operations():
    # Funksiyalarni yozing
    pass

def payment_operations():
    while True:
        operation = input("""
            Payment Operations
            1. Select
            2. Insert
            3. Update
            4. Delete
            5. Back
            >>> """)

        if operation == "1":
            # Select operation
            payments = Payments.select_payments()
            print("Payments:")
            for payment in payments:
                print(payment)

        elif operation == "2":
            customer_id = input("Enter customer ID: ")
            amount = float(input("Enter payment amount: "))
            payment_date = input("Enter payment date (YYYY-MM-DD): ")
            Payments.insert_payment(customer_id, amount, payment_date)

        elif operation == "3":
            payment_id = input("Enter payment ID: ")
            new_amount = float(input("Enter new payment amount: "))
            new_payment_date = input("Enter new payment date (YYYY-MM-DD): ")
            Payments.update_payment(payment_id, new_amount, new_payment_date)

        elif operation == "4":
            payment_id = input("Enter payment ID to delete: ")
            Payments.delete_payment(payment_id)

        elif operation == "5":
            break

        else:
            print("Invalid operation!")

if __name__ == "__main__":
    user_operations()
    payment_operations()