import time
from datetime import datetime


def task_1():
    time.sleep(2)

    print("call 1")
    print("end task 1")


def task_2():
    time.sleep(2)

    print("call 2")
    task_3()
    print("end task 2")


def task_3():
    time.sleep(2)

    print("call 3")
    print("end task 3")


def task_4():
    time.sleep(2)

    print("call 4")
    print("end task 4")


def task_5():
    time.sleep(2)

    print("call 5")
    print("end task 5")


def task_6():
    time.sleep(2)

    print("call 6")
    print("end task 6")


def task_7():
    time.sleep(2)

    print("call 7")
    print("end task 7")


def task_8():
    time.sleep(2)

    print("call 8")
    print("end task 8")


def task():
    print(datetime.now())
    task_1()
    task_2()
    task_3()
    task_4()
    task_5()
    task_6()
    task_7()
    task_8()
    print(datetime.now())


if __name__ == "__main__":
    task()
